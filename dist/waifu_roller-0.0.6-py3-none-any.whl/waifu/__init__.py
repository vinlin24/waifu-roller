"""Package for the waifu-roller project."""

__version__ = "0.0.6"
__author__ = "Vincent Lin"
