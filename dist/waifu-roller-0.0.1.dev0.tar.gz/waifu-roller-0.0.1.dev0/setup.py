"""
setup.py
23 July 2022 00:06:47
"""

from setuptools import setup

# Configuration set up in setup.cfg
setup()
