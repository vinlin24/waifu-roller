"""Package for the waifu-roller project."""

__version__ = "0.0.1"
__author__ = "Vincent Lin"
