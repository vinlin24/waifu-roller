# Work in Progress!!

## Description

**Command line tool for rolling anime/game characters with the Discord bot [Mudae](https://top.gg/bot/432610292342587392).**

Suppose you're in the zone coding, but it's a new hour and you can roll for waifus again. Before you'd switch to Discord, find the channel, and brainlessly spam enter `$wa` or something. Now you can start the whole rolling sequence right from your command line (that you as a 10x developer always have open 🙂).
```
$ roll -c waifu-spam -n 10
```

This project uses [PyAutoGUI](https://pypi.org/project/PyAutoGUI/) to automate the process of switching to the app, navigating to the channel, and entering commands. **No asking for user tokens, no Discord self-botting.**

## Installation

Bro I haven't even finished the damn thing yet lol.